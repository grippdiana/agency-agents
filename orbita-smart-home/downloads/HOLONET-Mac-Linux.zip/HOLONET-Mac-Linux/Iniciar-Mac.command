#!/bin/bash
cd "$(dirname "$0")"
INSTALL_DIR="$HOME/.holonet-desktop"
mkdir -p "$INSTALL_DIR"
cp -R server.js package.json public docs "$INSTALL_DIR/" 2>/dev/null || true

if ! command -v node >/dev/null 2>&1; then
  osascript -e 'display dialog "Para rodar no macOS, instale o Node.js gratuito em https://nodejs.org e clique novamente em Iniciar-Mac.command." buttons {"OK"} default button "OK" with title "HOLONET Desktop"'
  open "https://nodejs.org"
  exit 1
fi

cd "$INSTALL_DIR"
if [ ! -d "node_modules" ]; then
  npm install --omit=dev --no-audit --no-fund
fi

# Configura início automático ao ligar o Mac (LaunchAgent)
PLIST="$HOME/Library/LaunchAgents/com.holonet.desktop.plist"
mkdir -p "$HOME/Library/LaunchAgents"
NODE_BIN="$(command -v node)"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.holonet.desktop</string>
  <key>ProgramArguments</key>
  <array>
    <string>$NODE_BIN</string>
    <string>$INSTALL_DIR/server.js</string>
  </array>
  <key>WorkingDirectory</key><string>$INSTALL_DIR</string>
  <key>EnvironmentVariables</key>
  <dict><key>PORT</key><string>3077</string></dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
</dict>
</plist>
EOF
launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST" 2>/dev/null || PORT=3077 nohup "$NODE_BIN" "$INSTALL_DIR/server.js" >/tmp/holonet.log 2>&1 &

sleep 1.5
if [ -d "/Applications/Google Chrome.app" ]; then
  open -na "Google Chrome" --args --app="http://127.0.0.1:3077"
elif [ -d "/Applications/Microsoft Edge.app" ]; then
  open -na "Microsoft Edge" --args --app="http://127.0.0.1:3077"
else
  open "http://127.0.0.1:3077"
fi
