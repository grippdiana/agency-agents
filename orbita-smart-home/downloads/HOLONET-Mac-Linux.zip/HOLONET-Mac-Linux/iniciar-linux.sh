#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
INSTALL_DIR="$HOME/.local/share/holonet-desktop"
mkdir -p "$INSTALL_DIR"
cp -r server.js package.json public docs "$INSTALL_DIR/"

if ! command -v node >/dev/null 2>&1; then
  xdg-open "https://nodejs.org" 2>/dev/null || true
  echo "Instale o Node.js (https://nodejs.org) e rode novamente ./iniciar-linux.sh"
  exit 1
fi

cd "$INSTALL_DIR"
if [ ! -d "node_modules" ]; then
  npm install --omit=dev --no-audit --no-fund
fi

cat > "$INSTALL_DIR/run-holonet.sh" <<'EOF'
#!/usr/bin/env bash
cd "$HOME/.local/share/holonet-desktop"
if ! curl -sf http://127.0.0.1:3077/api/health >/dev/null 2>&1; then
  PORT=3077 nohup node server.js >/tmp/holonet.log 2>&1 &
  sleep 1.2
fi
if [ "$1" != "--background" ]; then
  for br in google-chrome chromium chromium-browser microsoft-edge brave-browser; do
    if command -v "$br" >/dev/null 2>&1; then
      "$br" --app="http://127.0.0.1:3077" >/dev/null 2>&1 &
      exit 0
    fi
  done
  xdg-open "http://127.0.0.1:3077" >/dev/null 2>&1 &
fi
EOF
chmod +x "$INSTALL_DIR/run-holonet.sh"

# Inicialização automática ao ligar o computador (XDG Autostart)
mkdir -p "$HOME/.config/autostart" "$HOME/.local/share/applications"
cat > "$HOME/.config/autostart/holonet-desktop.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=HOLONET Desktop (Boot)
Comment=Inicia o servidor HOLONET automaticamente ao ligar o PC
Exec=$INSTALL_DIR/run-holonet.sh --background
Icon=$INSTALL_DIR/public/icon-192.png
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

cat > "$HOME/.local/share/applications/holonet-desktop.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=HOLONET Desktop
Comment=Console Doméstico Star Wars (Samsung Crystal 55, Tuya, LG ThinQ)
Exec=$INSTALL_DIR/run-holonet.sh
Icon=$INSTALL_DIR/public/icon-192.png
Terminal=false
Categories=Utility;Network;
EOF

if [ -d "$HOME/Desktop" ]; then
  cp "$HOME/.local/share/applications/holonet-desktop.desktop" "$HOME/Desktop/HOLONET-Desktop.desktop"
  chmod +x "$HOME/Desktop/HOLONET-Desktop.desktop"
fi

"$INSTALL_DIR/run-holonet.sh"
